#Duncan Keller 2/21/24
#Grabs LoRa Data From RP2040 Running "CAN Sniffer" and
#Writes Data to SQLite DB file in /home/fsae2024/desktop/RFM95.x

import sqlite3
import time
import busio
from digitalio import DigitalInOut, Direction, Pull
import board
import adafruit_ssd1306
import adafruit_rfm9x

# Create the I2C interface.
i2c = busio.I2C(board.SCL, board.SDA)

# 128x32 OLED Display
reset_pin = DigitalInOut(board.D4)
display = adafruit_ssd1306.SSD1306_I2C(128, 32, i2c, reset=reset_pin)

# Clear the display.
display.fill(0)
display.show()
width = display.width
height = display.height

# Configure LoRa Radio
CS = DigitalInOut(board.CE1)
RESET = DigitalInOut(board.D25)
spi = busio.SPI(board.SCK, MOSI=board.MOSI, MISO=board.MISO)
rfm9x = adafruit_rfm9x.RFM9x(spi, CS, RESET, 915.0)
rfm9x.tx_power = 23
rfm9x.spreading_factor = 8
rfm9x.receive_timeout = 5.0
rfm9x.coding_rate = 5
rfm9x.signal_bandwidth = 250000
#Header ID or RP240
ID = 0x22

#Setup Variables
count = 0       #Count of Packets
packet = None   #Raw LoRa Packet
data = []     #Converted LoRa Data

#Start Timer for elapsed time
startTime = time.time()

while True:
    # check for packet rx returned in bytes
    packet = rfm9x.receive(with_header=True)
    if packet is None:
        display.show()
        packetNum = "Packet Number: " + str(count) 
        rssi = "Last RSSI: " + str(rfm9x.rssi)
        display.text(packetNum, 15, 10, 1)
        display.text(rssi,15,20,1)
        
    
    elif packet[1] == ID:
        # Display the packet number & RSSI
        display.fill(0)
        count += 1
        packetNum = "Packet Number: " + str(count) 
        rssi = "Last RSSI: " + str(rfm9x.rssi)
        display.text(packetNum, 15, 10, 1)
        display.text(rssi,15,20,1)
        display.show()
        
        #Print Part of Packet To Terminal for Debugging
        for x in range(4,len(packet),2):
            val = packet[x] | (packet[x+1] << 8)
            
            #CAN REMOVE AND ADD TO GRAFANA??folding rack 
            #Check if value needs is negative
            #NOTE this is assuming all values are signed values or
            #That the unsigned dont go higher than 32766
            if val > 32767:
                val = val - 65536
                
            if (x>=2 and x <=7) or (x>=42 and x<=45):
                val = val / 10
            elif (x>=48 and x <=53) or (x>=8 and x<=13) or x==40:
                val = val / 100
            elif(x>=16 and x <=31):
                val = val / 1000
            
            #Append new Value onto final list
            data.append(val)
            
        #Append Time data
        data.append(round(time.time() - startTime,2))
        print(data)
        
        #Connection and cursor for SQLite DB
        conn = sqlite3.connect("dataBase.db")
        cursor = conn.cursor()
        
        data_tuple=tuple(data)
        
        cursor.execute("INSERT INTO liveData VALUES " + str(data_tuple))
            
        conn.commit()
        conn.close() # Close SQLite conncetion
        data = [] #Clear Data
    
